from django.db import models
from django.contrib.auth import User
# Create your models here.
class Proveedor(User):
     None