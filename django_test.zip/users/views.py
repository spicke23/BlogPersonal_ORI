from wsgiref.util import request_uri
from django.shortcuts import render
from .forms import UserRegisterForm, UserForm, UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            print('usuario registrado'+ username)
    else:
        form = UserRegisterForm()

    
    return render(request, 'users/register.html', {'form': form})

def createUser(request):
    if request.method == 'POST':
        form = UserForm( data = request.POST)
        if form.is_valid():
            nombre=form.cleaned_data["username"]
            email=form.cleaned_data["email"]
            password=form.cleaned_data["password"]
            user = User.objects.create_user(nombre,email, password)
            user.save()
        return render(request, 'users/createUser.html') 
    else:
        form = UserForm()
        return render(request, 'users/createUser.html', {'form':form })
   

    


@login_required
def profile(request):
    return render(request, 'users/profile.html')