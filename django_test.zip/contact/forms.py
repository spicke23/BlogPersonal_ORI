from django import forms
from .models import Snippet

class ContactForm(forms.Form):
    nombre = forms.CharField()
    email = forms.EmailField(label = 'Email')
    categoria = forms.ChoiceField(choices = [('pregunta','Pregunta'),('etc','Etc')])
    body = forms.CharField(widget=forms.Textarea)

class SnippetForm(forms.ModelForm):
    class Meta:
        model = Snippet
        fields = {'name','body'}