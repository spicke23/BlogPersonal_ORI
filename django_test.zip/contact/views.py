from ast import If
from django.shortcuts import render
from django.http import HttpResponse
from .forms import ContactForm, SnippetForm
# Create your views here.

def contact(request):
    if request.method == 'POST':
        form =  ContactForm(request.POST)
        if form.is_valid():
            nombre =  form.cleaned_data['nombre']
            email = form.cleaned_data['email']

            print(nombre, email)

    form = ContactForm()
    return render(request, 'contact/forms.html', {'form': form})

def snippet_detail(request):
    if request.method == 'POST':
        form =  SnippetForm(request.POST)
        if form.is_valid():
            form.save()
            print("Funciona")
    form = SnippetForm()
    return render(request, 'contact/forms.html', {'form': form})