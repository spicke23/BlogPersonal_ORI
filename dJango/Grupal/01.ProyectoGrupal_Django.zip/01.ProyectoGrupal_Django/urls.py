#from django.conf.urls import url
#from django.contrib import admin

#from boards import views

#urlpatterns = [
#    url(r'^$', views.home, name='home'),
#    url(r'^admin/', admin.site.urls),
#]

from django.urls import path
from . import views
 
urlpatterns = [
    path('', views.saludo, name='index'),
]