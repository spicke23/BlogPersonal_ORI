#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse

posts = [
    {
        'pageTitle':'Título de la Página en Python',
        'messagePrincipal': 'Bienvenido a TeLoVendo S.A.'
    }
]


def saludo(request):
    #return HttpResponse("<h1>Bienvenidos a Te Lo Vendo</h1>")
    context = {
        'posts': posts
    }
    return render(request,'ProyectoGrupal/index.html',context)