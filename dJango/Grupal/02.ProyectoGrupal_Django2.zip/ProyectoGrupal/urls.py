from django.urls import path
from . import views
 
urlpatterns = [
    path('', views.saludo, name='mensaje-bienvenida'), ## '', llamado a metodo saludo de vista, tag de identificacion
]