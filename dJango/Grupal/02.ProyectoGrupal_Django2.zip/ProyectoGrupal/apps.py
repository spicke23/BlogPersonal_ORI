from django.apps import AppConfig


class ProyectogrupalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ProyectoGrupal'
